<?php
// we must never forget to start the session
session_start();

$errorMessage = '';
if (isset($_POST['txtUserId']) && isset($_POST['txtPassword'])) {
	// check if the username and password combination is correct
	if ($_POST['txtUserId'] === 'admin' && $_POST['txtPassword'] === 'kavi') {
		// the username and password match, 
		// set the session
		$_SESSION['basic_is_logged_in'] = true;
		
		// after login we move to the main page
		header('Location: home.php');
		exit;
	} else {
		$errorMessage = 'Sorry, wrong Username / Password';
	}
}
?>
<html>
<head>
<title>Global Dreamz  - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="javascript" type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">

function form_validate()
{
    valid = true;
	var emailPat=/^(.+)@(.+)\.(.+)$/;
	
	if(document.frmLogin.txtUserId.value == "")
	{
	    alert("Please enter the User Name");
		valid = false;
	}
	
	 else if ( document.frmLogin.txtPassword.value == "")
    {
        alert ( "Please enter the Password" );
        valid = false;
    }
		
	/*else
	{
	   alert("Mail Sent Successfully!");
	   	}*/
	 return valid;
}


</script>


<style type="text/css">
	.text{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a:hover{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#ff0000;
	}
</style>

</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="562" height="417" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01" >
	
<tr> 
		<td height='157' align="center" valign="top">
		<img src="images/banner.jpg" width="626" height="82"></td>
  </tr>
	
		
	<tr>
		<td height="214" align="center" valign="top">
        
        <?php
if ($errorMessage != '') {
?>
<p align="center" class="text" style="color:#ff0000;"><?php echo $errorMessage; ?></p>
<?php
}
?>
<form action="" method="post" name="frmLogin" id="frmLogin" onSubmit="return form_validate();">
 <table width="433" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
   <td width="93" height="35" class="text">User Id</td>
   <td width="340" class="text" style="color:#ff0000"><input name="txtUserId" type="text" id="txtUserId" size="44"> 
   *</td>
  </tr>
  <tr>
   <td width="93" height="40" class="text">Password</td>
   <td><input name="txtPassword" type="password" id="txtPassword" size="44">
     <span class="text" style="color:#ff0000">*</span></td>
  </tr>
  <tr>
   <td width="93">&nbsp;</td>
   <td><input name="btnLogin" type="submit" id="btnLogin" value="Login">
     <input name="reset" type="reset" id="btnLogin2" value="Reset"></td>
  </tr>
 </table>
</form>
                
        
      </td>
  </tr>
	<tr>
		<td height="26" align="center" valign="top"><span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; ">Developed by Kavi</span></td>
	</tr>
	<tr>
		<td height="19">&nbsp;</td>
	</tr>
</table>

</body>
</html>