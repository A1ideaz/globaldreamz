<?php
if(isset($_POST['save']))
{
 //mb_internal_encoding("UTF-8");
 $app_root = $_SERVER["DOCUMENT_ROOT"];
 $content = $_POST['elm1'];
 $to_addr = $_POST['to_addr'];
 
 $subject = $_POST['subject'];

$words = split(",", $to_addr);

foreach($words as $mailsids)
	{
	//echo $mailsids;
	sleep(1);
// multiple recipients
 $to  = $mailsids; 

// subject
$subject = 'Global Dreamz - Season Greetings';

// message
$receipt = "
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<title>Global Dreamz - Season Greetings</title>
</head>

<body> <img src='http://www.globaldreamz.com/mail/images/greetings/new-year2010.jpg' border='0' alt='Global Dreamz - New year 2010 Greetings' />
</body>
</html>
";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
//$headers .= 'To:Kavi<kannadhasan.j@gmail.com>' . "\r\n";
$headers .= 'From: Global Dreamz <guidance@globaldreamz.com>' . "\r\n" ."";


// Mail it
mail($to, $subject, $receipt, $headers);
//echo "mail sent successfully";
header("Location: http://www.globaldreamz.com/mail/greetings.php");


}

}?>