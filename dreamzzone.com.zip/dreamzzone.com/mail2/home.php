<?php
// like i said, we must never forget to start the session
session_start();

// is the one accessing this page logged in or not?
if (!isset($_SESSION['basic_is_logged_in']) || $_SESSION['basic_is_logged_in'] !== true) {
	// not logged in, move to login page
	header('Location: login.php');
	exit;
}

?>
<html>
<head>
<title>Global Dreamz - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="javascript" type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">

function form_validate()
{
    valid = true;
	var emailPat=/^(.+)@(.+)\.(.+)$/;
	
	if(document.newsletter.name.value == "")
	{
	    alert("Please enter the Name");
		valid = false;
	}
	
	 else if ( document.newsletter.to_addr.value == "")
    {
        alert ( "Please enter your Email Address" );
        valid = false;
    }
	else if (document.newsletter.to_addr.value.search(emailPat)==-1)
  	{
    	alert ( "Please enter a valid Email Address" );
        valid = false;
 	}
	
	else if(document.newsletter.amount.value == "")
	{
	   alert("Please enter the Amount");
	  valid = false;
	}
	
	else if(document.newsletter.word.value == "")
	{
	   alert("Please enter the Amount in Words");
	   valid = false;
	}
	
	else if(document.newsletter.towards.value == "")
	{
	   alert("Please enter Towards");
	   valid = false;
	}
	
	else if(document.newsletter.money.value == "")
	{
	   alert("Please enter the Cash / Money Transfer, Else Enter the Cheque #");
	   valid = false;
	}
	
	else if((document.newsletter.money.value == "Cheque")&&(document.newsletter.cheque.value == ""))
	{
	   alert("Please enter the Cheque #");
	   valid = false;
	}
	
	else
	{
	   alert("Mail Sent Successfully!");
	   	}
	 return valid;
}


</script>
<script language="javascript" type="text/javascript">


</script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,media,searchreplace,print,contextmenu,paste,directionality,fullscreen",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		content_css : "example_word.css",
	    plugi2n_insertdate_dateFormat : "%Y-%m-%d",
	    plugi2n_insertdate_timeFormat : "%H:%M:%S",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		media_external_list_url : "example_media_list.js",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		paste_auto_cleanup_on_paste : true,
		paste_convert_headers_to_strong : false,
		paste_strip_class_attributes : "all",
		paste_remove_spans : false,
		paste_remove_styles : false		
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}
</script>

<style type="text/css">
	.text{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a:hover{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#ff0000;
	}
</style>

</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="562" height="478" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01" >
	
<tr> 
		<td height='94' align="center" valign="top">
		<img src="images/banner.jpg" width="626" height="82"></td>
  </tr>
	
		
	<tr>
		<td height="336" align="right" valign="top">
        
        
        <table width="607" border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom:1px solid #e0e0e0;">
            <tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="right" valign="middle" class="text"><a href="logout.php">Logout</a></td>
          </tr>
            <tr>
              <td width="171" align="center" valign="middle">&nbsp;</td>
              <td width="189" align="center" valign="middle">&nbsp;</td>
              <td width="140" align="center" valign="middle">&nbsp;</td>
            </tr>
            
            <tr>
              <td align="center" valign="middle"><a href="receipt.php"><img src="images/tab-receipt.jpg" alt="Receipt" width="182" height="108" border="0"></a></td>
              <td align="center" valign="middle"><a href="voucher.php"><img src="images/tab-voucher.jpg" alt="Voucher" width="182" height="108" border="0"></a></td>
              <td align="center" valign="middle"><a href="mail.php"><img src="images/tab-mail.jpg" alt="Mail" width="182" height="108" border="0"></a></td>
          </tr>
            <tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
            </tr>
            <tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle"><a href="http://mail.google.com/a/globaldreamz.com" target="_blank"><img src="images/tab-webmail.jpg" alt="Global Dreamz Webmail Login" width="182" height="108" border="0"></a></td>
              <td align="center" valign="middle">&nbsp;</td>
            </tr>

            <tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
            </tr>
             <tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle"><a href="greetings.php">Send Greetings</a></td>
              <td align="center" valign="middle">&nbsp;</td>
            </tr>

			<tr>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
              <td align="center" valign="middle">&nbsp;</td>
            </tr>
          </table>
      </td>
  </tr>
	<tr>
		<td height="26" align="center" valign="top"><span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; ">Developed by Kavi</span></td>
	</tr>
	<tr>
		<td height="19">&nbsp;</td>
	</tr>
</table>

</body>
</html>
