<?php
if(isset($_POST['save']))
{
// mb_internal_encoding("UTF-8");
 $app_root = $_SERVER["DOCUMENT_ROOT"];
 $contents = $_POST['elm1'];
 
 $name = $_POST['name'];
 $to_addr = $_POST['to_addr'];
 
 $subject = $_POST['subject'];
 
 $amount = $_POST['amount'];
 $word = $_POST['word'];

 if($_post['towards']=="Other")
{
 $towards = $_POST['other'];
echo "if";
}
 else
{
 $towards = $_post['towards'];
}
 $money = $_POST['money'];
 
 $cheque = $_POST['cheque'];

 $content = 'Dear <strong>'.$_POST['name'].'</strong>!<br><br>

We hereby acknowledge the receipt of Rs <strong> '.$_POST['amount'].' </strong>( <strong>'.$_POST['word'].'</strong> ) towards <strong> '.$towards.'</strong> through <strong>'.$_POST['money'].' '.$_POST['cheque'].'</strong>. Your account has been credited for the above amount.

<br><br><br>
Thanks & Regards,
<br>
<strong>Global Dreamz</strong>';
  

$words = split(",", $to_addr);

foreach($words as $mailsids)
	{
	//echo $mailsids;
	sleep(1);
// multiple recipients
 $to  = $mailsids; 

// subject
//$subject = 'Global Dreamz Payment Receipt';

// message
$receipt = "
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<title>Global Dreamz Voucher</title>
</head>

<body>
<table width='563' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor='#484848' style='padding-top:5px'>
  <tr>
    <td width='4'>&nbsp;</td>
    <td colspan='4' align='center' valign='top'><table width='551' border='0' cellspacing='0' cellpadding='0'>
	<tr>
		<td height='5' align='center' valign='top'></td>
	</tr>
      <tr>
        <td align='center' valign='top'><img src='http://www.globaldreamz.com/mail/images/header.jpg' alt='Header' width='551' height='92' /></td>
      </tr>
      <tr>
        <td align='center' valign='top' bgcolor='#f5fade'>
        
        <table width='551' border='0' align='center' cellpadding='0' cellspacing='0'>
          <tr>
            <td height='60' align='center' valign='middle' style='font-family:Arial, Helvetica, sans-serif; font-size:24px; color:#000000;'>Payment Receipt</td>
          </tr>
          <tr>
            <td align='center' valign='top'>
            
            <table width='520' border='0' align='center' cellpadding='0' cellspacing='0'>
              <tr>
                <td height='106' align='left' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000;'>$content	
				</td>
              </tr>
              <tr>
                <td align='right' valign='top'><img src='http://www.globaldreamz.com/mail/images/payment-received.jpg' alt='Payment Received' width='163' height='123' border='0'></td>
              </tr>
              <tr>
                <td align='left' valign='top'>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td align='center' valign='top'>&nbsp;</td>
          </tr>
          <tr>
            <td align='center' valign='top'><img src='http://www.globaldreamz.com/mail/images/footer.jpg' alt='Footer' width='551' height='121' /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align='center' valign='top'>&nbsp;</td>
      </tr>
    </table></td>
    <td width='4'>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width='11'>&nbsp;</td>
    <td width='240' align='left' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#bcbcbc;'>Contact Address :<br />
      Global Dreamz<br />
      721, 11th B Cross, 25th Main,<br />
      HSR Layout 1st Sector, <br />
    Bangalore, Karnataka, India - 560102. </td>
    <td width='292' align='right' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#bcbcbc;'>
    TEL:  +91-99-00-20-66-66  /  +91-99-807-555-71<br />
      Email : <a href='mailto:guidance@globaldreamz.com' style='font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#ebebeb; text-decoration:none;'>guidance@globaldreamz.com</a><br />
      Web: <a href='http://www.globaldreamz.com/' target='_blank' style='font-family: Arial,Helvetica,sans-serif; font-size: 11px; color: #ebebeb; text-decoration: none;'>www.globaldreamz.com</a><br/><br/>
    Copyright  Global Dreamz</td>
    <td width='11' align='right' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#bcbcbc;'>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan='2'>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
//$headers .= 'To:Kavi<kannadhasan.j@gmail.com>' . "\r\n";
$headers .= 'From: Global Dreamz <guidance@globaldreamz.com>' . "\r\n" ."BCC:";


// Mail it
mail($to, $subject, $receipt, $headers);
//echo "mail sent successfully";
header("Location: http://www.globaldreamz.com/mail/receipt.php");


}

}?>