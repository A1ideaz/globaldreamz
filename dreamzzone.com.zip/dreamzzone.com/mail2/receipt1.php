<?php
// like i said, we must never forget to start the session
session_start();

// is the one accessing this page logged in or not?
if (!isset($_SESSION['basic_is_logged_in']) || $_SESSION['basic_is_logged_in'] !== true) {
	// not logged in, move to login page
	header('Location: index.php');
	exit;
}

?>
<html>
<head>
<title>Global Dreamz - Control Panel</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>

<script language='javascript' type='text/javascript' src='jscripts/tiny_mce/tiny_mce.js'></script>
<script language='javascript' type='text/javascript'>

function form_validate()
{
    valid = true;
	var emailPat=/^(.+)@(.+)\.(.+)$/;
	
	if(document.newsletter.name.value == '')
	{
	    alert('Please enter the Name');
		valid = false;
	}
	
	 else if ( document.newsletter.to_addr.value == '')
    {
        alert ( 'Please enter your Email Address' );
        valid = false;
    }
	
	else if (document.newsletter.to_addr.value.search(emailPat)==-1)
  	{
    	alert ( 'Please enter a valid Email Address' );
        valid = false;
 	}
	
	 else if ( document.newsletter.subject.value == '')
    {
        alert ( 'Please enter the Subject' );
        valid = false;
    }
	
	else if(document.newsletter.amount.value == '')
	{
	   alert('Please enter the Amount');
	  valid = false;
	}
	
	else if(document.newsletter.word.value == '')
	{
	   alert('Please enter the Amount in Words');
	   valid = false;
	}
	
	else if(document.newsletter.towards.value == '')
	{
	   alert('Please enter Towards');
	   valid = false;
	}
	
	else if(document.newsletter.money.value == '')
	{
	   alert('Please enter the Cash / Money Transfer, Else Enter the Cheque #');
	   valid = false;
	}
	
	else if((document.newsletter.money.value == 'Cheque')&&(document.newsletter.cheque.value == ''))
	{
	   alert('Please enter the Cheque #');
	   valid = false;
	}
	
	else
	{
	   alert('Mail Sent Successfully!');
	   	}
	 return valid;
}


</script>
<script language='javascript' type='text/javascript'>


</script>
<script language='javascript' type='text/javascript'>
	tinyMCE.init({
		mode : 'textareas',
		theme : 'advanced',
		plugins : 'table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,media,searchreplace,print,contextmenu,paste,directionality,fullscreen',
		theme_advanced_buttons1_add_before : 'save,newdocument,separator',
		theme_advanced_buttons1_add : 'fontselect,fontsizeselect',
		theme_advanced_buttons2_add : 'separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor',
		theme_advanced_buttons2_add_before: 'cut,copy,paste,pastetext,pasteword,separator,search,replace,separator',
		theme_advanced_buttons3_add_before : 'tablecontrols,separator',
		theme_advanced_buttons3_add : 'emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen',
		theme_advanced_toolbar_location : 'top',
		theme_advanced_toolbar_align : 'left',
		theme_advanced_statusbar_location : 'bottom',
		content_css : 'example_word.css',
	    plugi2n_insertdate_dateFormat : '%Y-%m-%d',
	    plugi2n_insertdate_timeFormat : '%H:%M:%S',
		external_link_list_url : 'example_link_list.js',
		external_image_list_url : 'example_image_list.js',
		media_external_list_url : 'example_media_list.js',
		file_browser_callback : 'fileBrowserCallBack',
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : '_something=My somthing;_something2=My somthing2;_something3=My somthing3;',
		paste_auto_cleanup_on_paste : true,
		paste_convert_headers_to_strong : false,
		paste_strip_class_attributes : 'all',
		paste_remove_spans : false,
		paste_remove_styles : false		
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert('Filebrowser callback: field_name: ' + field_name + ', url: ' + url + ', type: ' + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = 'someurl.htm';
	}
</script>

<style type='text/css'>
	.text{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
	}

.text a:hover{
	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#ff0000;
	}
</style>

</head>
<body bgcolor='#FFFFFF' leftmargin='0' topmargin='0' marginwidth='0' marginheight='0'>

<table width='562' height='557' border='0' align='center' cellpadding='0' cellspacing='0' id='Table_01'>
	
<tr> 
		<td height='108' align='center' valign='top'>
		<img src='images/banner.jpg' width='626' height='82' border='0' usemap='#Map'></td>
  </tr>
	<tr>
	  <td height='63' align='center' valign='top'><table width='630' border='0' align='center' cellpadding='0' cellspacing='0'>
        
        <tr>
          <td height='20' align='center' valign='middle'>&nbsp;</td>
          <td align='center' valign='middle'>&nbsp;</td>
          <td height='27' align='center' valign='top'><a href='home.php' class='text'>Home</a> | <a href='logout.php' class='text'>Logout</a></td>
        </tr>
        <tr>
          <td width='152' height='50' align='center' valign='middle'><span style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; text-decoration:none;'><span>&raquo;</span> <a href='mail.php' style='text-decoration:none;'>Send Formal mail</a></span></td>
          <td width='323' align='center' valign='middle'><span style='font-family:Arial, Helvetica, sans-serif; font-size:24px; color:#000000;'>Send Payment Receipt</span></td>
          <td width='155' align='center' valign='middle'><span style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; text-decoration:none;'><span>&raquo;</span> <a href='voucher.php' style='text-decoration:none;'>Send Voucher Receipt</a></span></td>
        </tr>
      </table></td>
  </tr>
	
	
	<tr>
		<td height='306' align='right' valign='top'><table width='500' border='0' align='center' cellpadding='0' cellspacing='0'>
            <tr>
              <td align='center' valign='middle'><form method='post' action='dreamzreceipt.php' name='newsletter' onSubmit='return form_validate();'>
                <table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>
                  <tr>
                    <td width='32%' height='30' align='right' valign='middle' class='text'>Name :</td>
                    <td width='4%' height='30' align='center' valign='middle'>&nbsp;</td>
                    <td width='64%' height='30' align='left' valign='middle'><input type='text' size='44' name='name' value='' id='name'></td>
                  </tr>
                  <tr>
                    <td height='28' align='right' valign='middle' class='text'>To :</td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='to_addr' value='' id='to_addr'></td>
                  </tr>
                  <tr>
                    <td height='31' align='right' valign='middle' class='text'>Subject :</td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='subject' value='' id='subject'></td>
                  </tr>
                  <tr>
                    <td height='31' align='right' valign='middle' class='text'>Amount : </td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='amount' value='' id='amount'></td>
                  </tr>
                  <tr>
                    <td height='26' align='right' valign='middle' class='text'>Amount in Words :</td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='word' value='' id='word'></td>
                  </tr>
                  <tr>
                    <td height='26' align='right' valign='middle' class='text'>Towards :</td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='towards' value='' id='towards'></td>
                  </tr>
                  <tr>
                    <td height='39' align='right' valign='middle' class='text'> Cash / Money Transfer /<br>
                      Cheque:</td>
                    <td height='39' align='center' valign='middle'>&nbsp;</td>
                    <td height='39' align='left' valign='middle'><select name='money' id='money' style='width:290px'>
                        <option>Cash</option>
                        <option>Money Transfer</option>
                        <option>Cheque #</option>
                      </select>                    </td>
                  </tr>
                  <tr>
                    <td height='31' align='right' valign='middle' class='text'> Cheque # :</td>
                    <td height='30' align='center' valign='middle'>&nbsp;</td>
                    <td height='30' align='left' valign='middle'><input type='text' size='44' name='cheque' value='' id='cheque'></td>
                  </tr>
                  <tr>
                    <td height='19' align='right' valign='middle' class='text'>&nbsp;</td>
                    <td height='19' align='center' valign='middle'>&nbsp;</td>
                    <td height='19' align='left' valign='middle'>&nbsp;</td>
                  </tr>
                </table>
                <!--
    <label style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000;'>To:&nbsp;</label>
	<input type='text' size='44' name='to_addr123' value='' id='to_addr123'> -->
                <!--<textarea id='elm1' name='elm1' rows='15' cols='80' style='width:100%; font-size:12px'>
		

	Dear Mr Kavi! <br /><br />

	We hereby acknowledge the receipt of Rs 10 000 (in words Ten Thousand Only) towards Registration through Cash / cheque #. Your account has been credited for the above amount in 14 Mar, 2008.

	<br /><br />

	Thanks & Regards,<br /><br />

	Dreamz International


	</textarea> -->
                <input type='submit' name='save' value='Submit'/>
                <input type='reset' name='reset' value='Reset' />
                <!--<input type='button' name='preview' value='preview' onClick='window.open('preview.php','myExample4','width=600,height=500,top=400,left=400,scrollbars=yes');'>-->
                                          </form></td>
            </tr>
          </table>
	    </p></td>
  </tr>
	<tr>
		<td align='center' valign='top'><span style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; '>Developed by Kavi</span></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;			</td>
	</tr>
	<tr>
		<td height='22'>&nbsp;</td>
	</tr>
</table>


<map name='Map'><area shape='rect' coords='20,9,161,74' href='home.php' alt='Home'>
</map></body>
</html>