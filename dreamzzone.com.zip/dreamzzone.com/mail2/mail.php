<?php
// like i said, we must never forget to start the session
session_start();

// is the one accessing this page logged in or not?
if (!isset($_SESSION['basic_is_logged_in']) || $_SESSION['basic_is_logged_in'] !== true) {
	// not logged in, move to login page
	header('Location: index.php');
	exit;
}

?>
<html>
<head>
<title>Global Dreamz - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="javascript" type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">

function form_validate()
{
    valid = true;
	if(document.newsletter.to_addr.value == "")
	{
	    alert("Plaese enter email ids");
		return false;
	}
	else if(document.newsletter.elm1.value == "")
	{
	   alert("Please enter content in textfield");
	   return false;
	}
	
	else
	{
	   alert("Mail sent successfully!");
	   return valid;
	}
	
}


</script>
<script language="javascript" type="text/javascript">


</script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,media,searchreplace,print,contextmenu,paste,directionality,fullscreen",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		content_css : "example_word.css",
	    plugi2n_insertdate_dateFormat : "%Y-%m-%d",
	    plugi2n_insertdate_timeFormat : "%H:%M:%S",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		media_external_list_url : "example_media_list.js",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		paste_auto_cleanup_on_paste : true,
		paste_convert_headers_to_strong : false,
		paste_strip_class_attributes : "all",
		paste_remove_spans : false,
		paste_remove_styles : false		
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}
</script>

<style type="text/css">
<!--
.text {	font-family: Arial, Helvetica, sans-serif; 
	font-size:12px; 
	color:#000000;
}
-->
</style>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="562" height="586" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
	<tr>
		<td height='108' colspan="5" align="center" valign="top"><img src="images/banner3.jpg" width="626" height="82" border="0" usemap="#Map">
		  <map name="Map">
		    <area shape="rect" coords="20,9,161,74" href="home.php" alt="Home">
          </map>	    </td>
  </tr>
	<tr>
	  <td height='21' colspan="2" align='center' valign='top'>&nbsp;</td>
	  <td height='21' align='center' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:24px; color:#000000;'>&nbsp;</td>
	  <td height='50' colspan='2' align='center' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; text-decoration:none;'><a href="home.php" class="text">Home</a> | <a href="logout.php" class="text">Logout</a></td>
  </tr>
	<tr>
	  <td height='21' colspan="2" align='center' valign='top'><span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; text-decoration:none;"><span>&raquo;</span> <a href="receipt.php" style='text-decoration:none;'>Send Payment Receipt</a></span></td>
	  <td width='279' height='21' align='center' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:24px; color:#000000;'>

		<span style="font-family:Arial, Helvetica, sans-serif; font-size:24px; color:#000000;">Send a Mail</span>	</td>
	  <td height='50' colspan='2' align='center' valign='top' style='font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; text-decoration:none;'><span>&raquo;</span> <a href="voucher.php" style='text-decoration:none;'>Send Voucher Receipt</a></td>
  </tr>
	
	<tr>
		<td width="86" height="348" align="right" valign="top">&nbsp;</td>
		<td colspan="3" align="center" valign="top"><p style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; color:#000000; line-height:13px'> <form method="post" action="dreamzmail.php" name="newsletter" onSubmit="return form_validate();">
	
	<label style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000;'>To:&nbsp;</label><input type='text' size="44" name="to_addr" value=""><br><br>
    <label style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000;'>Subject:&nbsp;</label>
    <input type='text' size="44" name="subject" value="" id="subject">
    <br><br>
	<textarea id="elm1" name="elm1" rows='15' cols="80" style='width:100%; font-size:12px'></textarea>
	<br />
	
	<input type="submit" name="save" value="Submit"/>
	<input type="reset" name="reset" value="Reset" />
	<!--<input type="button" name="preview" value="preview" onClick="window.open('preview.php','myExample4','width=600,height=500,top=400,left=400,scrollbars=yes');">-->
</form></p></td>
		<td width="91" align="left" valign="top">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="5" align="center" valign="top"><span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; ">Developed by Kavi</span></td>
	</tr>
	<tr>
		<td colspan="5">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="5">&nbsp;			</td>
	</tr>
	<tr>
		<td height="22" colspan="5">&nbsp;</td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="77" height="1" alt=""></td>
		<td width="88">
			<img src="images/spacer.gif" width="73" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="257" height="1" alt=""></td>
		<td width="82">
			<img src="images/spacer.gif" width="74" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="81" height="1" alt=""></td>
	</tr>
</table>

</body>
</html>